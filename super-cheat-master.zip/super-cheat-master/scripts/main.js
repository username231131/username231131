
require('super-cheat/lib')
require('super-cheat/cheat-item')
require('super-cheat/must-die-turret')
require('super-cheat/enemys-cannot-move')
require('super-cheat/enemys-control')
require('super-cheat/enemys-no-damage')
require('super-cheat/enemys-remove')
require('super-cheat/invincible-core')
require('super-cheat/static-drill')
require('super-cheat/invincible-force-projector')
require('super-cheat/invincible-simple-blocks')
require('super-cheat/next-wave')
require('super-cheat/quantum-launchpad')
require('super-cheat/adjustable-overdrive-projector')
require('super-cheat/chrono-unloader')
require('super-cheat/chrono-pusher')
require('super-cheat/turret-turret')
require('super-cheat/dps-tester-unit')
require('super-cheat/unit-factory')
require('super-cheat/team-changer')

// Events.on(EventType.ClientLoadEvent, cons(e => {

//     Icon.trash = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("invincible-cheat-mod-v6-must-die-turret", Core.atlas.find("clear")))
//     Icon.icons.put("trash", Icon.trash);

//     Vars.ui.settings = new SettingsMenuDialog();

//     var dialog = new JavaAdapter(BaseDialog, {}, "si");
//     dialog.shown(run(() => {
//         dialog.cont.table(Tex.button, cons(t => {
//             t.defaults().size(280, 60).left();
//             t.button("aoisdjiasjdio", Icon.trash, Styles.cleart, run(() => {
//                 dialog.hide();
//             }));
//         }));
//     }));

//     dialog.show();
// }));
